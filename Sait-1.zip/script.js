jQuery(document).ready(function($){
  
  $('.button').on('click', function(e){
    alert('Действие выполнено');
  })
  
});